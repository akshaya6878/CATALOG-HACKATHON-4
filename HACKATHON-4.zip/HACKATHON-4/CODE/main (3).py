import hashlib
import os
import random
import string
import time
from datetime import datetime, timedelta
import re
import getpass

# Hash and salt function for secure password storage
def hash_password(password):
    salt = os.urandom(32)  # 32-byte random salt
    pwdhash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
    return salt + pwdhash

# Function to verify password
def verify_password(stored_password, provided_password):
    salt = stored_password[:32]
    stored_pwdhash = stored_password[32:]
    pwdhash = hashlib.pbkdf2_hmac('sha256', provided_password.encode('utf-8'), salt, 100000)
    return pwdhash == stored_pwdhash

# Function for CAPTCHA challenge
def captcha():
    chars = random.sample(string.ascii_letters + string.digits, 6)
    captcha_str = ''.join(chars)
    print(f"CAPTCHA: {captcha_str}")
    user_input = input("Enter the CAPTCHA: ")
    return user_input == captcha_str

# Validate password strength (at least 8 characters, 1 uppercase, 1 digit, 1 special char)
def validate_password(password):
    if len(password) < 8:
        print("Password must be at least 8 characters long.")
        return False
    if not any(c.isupper() for c in password):
        print("Password must contain at least one uppercase letter.")
        return False
    if not any(c.isdigit() for c in password):
        print("Password must contain at least one digit.")
        return False
    if not any(c in string.punctuation for c in password):
        print("Password must contain at least one special character.")
        return False
    return True

# Email format validation
def validate_email(email):
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    if re.match(email_regex, email):
        return True
    else:
        print("Invalid email format. Please enter a valid email address.")
        return False

# Simulated user database (in-memory)
user_db = {}
failed_attempts = {}
password_history = {}
password_expiry_days = 30  # Password expiration period (in days)
session_timeout_minutes = 5  # Session timeout after inactivity (in minutes)
user_sessions = {}

# Register a new user with a hashed password
def register_user(email, password, security_question, security_answer):
    if not validate_email(email):
        return
    if email in user_db:
        print("User with this email already exists.")
        return
    
    while True:
        password_confirmation = getpass.getpass("Confirm your password: ")
        if password != password_confirmation:
            print("Passwords do not match! Try again.")
        else:
            break

    # Store user data with password history and security question
    user_db[email] = {
        'password': hash_password(password),
        'password_history': [hash_password(password)],  # Store history
        'last_password_change': datetime.now(),
        'security_question': security_question,
        'security_answer': security_answer,
        'locked_until': None
    }
    print(f"User {email} registered successfully.")

# Password expiry checker
def is_password_expired(email):
    user_data = user_db.get(email)
    if not user_data:
        return False
    last_change = user_data['last_password_change']
    return datetime.now() > last_change + timedelta(days=password_expiry_days)

# Enforce password history (cannot reuse the last 3 passwords)
def is_password_reused(email, new_password):
    user_data = user_db[email]
    password_history = user_data['password_history'][-3:]
    new_password_hash = hash_password(new_password)
    return any(verify_password(stored_password, new_password) for stored_password in password_history)

# Force password reset if expired
def force_password_reset(email):
    print("Your password has expired. Please reset it.")
    while True:
        new_password = getpass.getpass("Enter new password: ")
        if validate_password(new_password) and not is_password_reused(email, new_password):
            confirm_password = getpass.getpass("Confirm new password: ")
            if new_password == confirm_password:
                user_db[email]['password'] = hash_password(new_password)
                user_db[email]['password_history'].append(hash_password(new_password))
                user_db[email]['last_password_change'] = datetime.now()
                print("Password reset successfully!")
                break
            else:
                print("Passwords do not match.")
        else:
            print("Password does not meet criteria or is reused. Try again.")

# Lockout mechanism after 3 failed attempts (lock for 30 seconds)
def lockout(email):
    if email not in failed_attempts:
        failed_attempts[email] = [0, 0]  # [failed attempts, timestamp]

    failed_attempts[email][0] += 1  # Increment failed attempts
    if failed_attempts[email][0] >= 3:
        failed_attempts[email][1] = time.time()  # Lock the account
        print("Account locked due to too many failed login attempts. Try again in 30 seconds.")
        return True
    return False

# Check if the user is currently locked out
def is_locked_out(email):
    if email in failed_attempts and time.time() - failed_attempts[email][1] < 30:
        return True
    return False

# Reset failed login attempts after a successful login
def reset_failed_attempts(email):
    if email in failed_attempts:
        failed_attempts[email] = [0, 0]

# Account recovery via security question
def account_recovery(email):
    if email not in user_db:
        print("No such user.")
        return False
    security_question = user_db[email]['security_question']
    print(f"Security Question: {security_question}")
    answer = input("Enter your answer: ")
    if answer == user_db[email]['security_answer']:
        force_password_reset(email)
        return True
    else:
        print("Incorrect answer.")
        return False

# Session timeout checker
def is_session_expired(email):
    if email in user_sessions:
        last_activity = user_sessions[email]
        return datetime.now() > last_activity + timedelta(minutes=session_timeout_minutes)
    return False

# Login function with password verification, password expiry check, lockout, and session timeout
def login_user(email, password):
    if email not in user_db:
        print("Invalid email or password.")
        return False
    
    if is_locked_out(email):
        print("Account is temporarily locked. Try again later.")
        return False

    # Check for session timeout
    if is_session_expired(email):
        print("Session expired due to inactivity. Please log in again.")
        return False

    # Password expiry check
    if is_password_expired(email):
        force_password_reset(email)
        return False
    
    stored_password = user_db[email]['password']
    if verify_password(stored_password, password):
        print("Password verified!")
        reset_failed_attempts(email)
        if captcha():
            print("CAPTCHA passed. Login successful.")
            user_sessions[email] = datetime.now()  # Record last activity
            return True
        else:
            print("CAPTCHA failed. Login failed.")
            return False
    else:
        print("Invalid email or password.")
        if lockout(email):
            return False
        return False

# Example usage with masked password input and show password feature
if __name__ == "__main__":
    while True:
        choice = input("Do you want to (r)egister, (l)ogin, (f)orgot password, or (q)uit? ").lower()
        if choice == 'r':
            email = input("Enter your email address: ")
            if not validate_email(email):
                print("Please enter a valid email address.")
                continue
            while True:
                password = getpass.getpass("Enter password (will not be shown): ")
                if validate_password(password):
                    break
            security_question = input("Enter a security question: ")
            security_answer = input("Enter answer to security question: ")
            register_user(email, password, security_question, security_answer)
        elif choice == 'l':
            print("\nLogin attempt:")
            login_email = input("Email: ")
            if not validate_email(login_email):
                print("Please enter a valid email address.")
                continue
            login_pass = getpass.getpass("Password (will not be shown): ")
            login_user(login_email, login_pass)
        elif choice == 'f':
            print("\nAccount recovery:")
            recovery_email = input("Email: ")
            if not validate_email(recovery_email):
                print("Please enter a valid email address.")
                continue
            account_recovery(recovery_email)
        elif choice == 'q':
            print("Exiting the system.")
            break
        else:
            print("Invalid choice. Please try again.")
